import { DosageFormDashboard } from "@/components/product-registration/dosage-form/dashboard"

export default function DosageFormsPage() {
  return <DosageFormDashboard />
}
