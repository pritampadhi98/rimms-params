import { PackagingDashboard } from "@/components/product-registration/packaging/dashboard"

export default function PackagingPage() {
  return <PackagingDashboard />
}
